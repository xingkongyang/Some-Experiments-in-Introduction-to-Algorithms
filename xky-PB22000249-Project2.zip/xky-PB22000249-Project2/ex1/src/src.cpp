#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>

// �������ڴ�ӡ�������Ż��������ļ�
void print_optimal_parens(int **s, int i, int j, FILE *output) {
    if (i == j) {
        fprintf(output, "A%d", i);
    } else {
        fprintf(output, "(");
        print_optimal_parens(s, i, s[i][j], output);
        print_optimal_parens(s, s[i][j] + 1, j, output);
        fprintf(output, ")");
    }
}

// �ڿ���̨�д�ӡ m ����
void print_m_table_console(int **m, int n) {
    printf("Table m[i][j] (Minimum Multiplications):\n");
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (j >= i) {
                printf("%7d ", m[i][j]);
            } else {
                printf("        ");
            }
        }
        printf("\n");
    }
    printf("\n");
}

// �ڿ���̨�д�ӡ s ����
void print_s_table_console(int **s, int n) {
    printf("Table s[i][j] (Optimal Split Points):\n");
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (j >= i) {
                printf("%7d ", s[i][j]);
            } else {
                printf("        ");
            }
        }
        printf("\n");
    }
    printf("\n");
}

// �������˷��Ķ�̬�滮���
void matrix_chain_order(int *p, int n, FILE *output, FILE *time_output) {
    int **m = (int **)malloc((n+1) * sizeof(int *));
    int **s = (int **)malloc((n+1) * sizeof(int *));
    for (int i = 0; i <= n; i++) {
        m[i] = (int *)malloc((n+1) * sizeof(int));
        s[i] = (int *)malloc((n+1) * sizeof(int));
    }

    // ��ʼ���Խ���Ԫ��
    for (int i = 1; i <= n; i++) m[i][i] = 0;

    // ��̬�滮�������ٳ˷�����
    for (int l = 2; l <= n; l++) {
        for (int i = 1; i <= n - l + 1; i++) {
            int j = i + l - 1;
            m[i][j] = INT_MAX;
            for (int k = i; k <= j - 1; k++) {
                int q = m[i][k] + m[k+1][j] + p[i-1] * p[k] * p[j];
                if (q < m[i][j]) {
                    m[i][j] = q;
                    s[i][j] = k;
                }
            }
        }
    }

    // ������ٳ˷��������������Ż��������ļ�
    fprintf(output, "Minimum number of multiplications is %d\n", m[1][n]);
    fprintf(output, "Optimal Parenthesization is: ");
    print_optimal_parens(s, 1, n, output);
    fprintf(output, "\n");

    // ��¼����ʱ�䵽�ļ�
    clock_t end = clock();
    double time_taken = ((double)(end)) / CLOCKS_PER_SEC;
    fprintf(time_output, "Time taken for n=%d: %f seconds\n", n, time_taken);

    // ��� n = 8��ֱ���ڿ���̨�������
    if (n == 8) {
        print_m_table_console(m, n);
        print_s_table_console(s, n);
    }

    // �ͷŶ�̬������ڴ�
    for (int i = 0; i <= n; i++) {
        free(m[i]);
        free(s[i]);
    }
    free(m);
    free(s);
}

int main() {
    // �ļ�·����ȷ��·����ȷ
    FILE *input = fopen("C:\\Users\\StarrySheep1\\Desktop\\xky-PB22000249-Project2\\ex1\\input\\2_1_input.txt", "r");
    FILE *output = fopen("C:\\Users\\StarrySheep1\\Desktop\\xky-PB22000249-Project2\\ex1\\output\\result.txt", "w");
    FILE *time_output = fopen("C:\\Users\\StarrySheep1\\Desktop\\xky-PB22000249-Project2\\ex1\\output\\time.txt", "w");

    if (input == NULL || output == NULL || time_output == NULL) {
        printf("Error opening files.\n");
        return 1;
    }

    int n;
    while (fscanf(input, "%d", &n) == 1) {  // ѭ����ȡÿ�����ݼ�
        int *p = (int *)malloc((n + 1) * sizeof(int));
        for (int i = 0; i <= n; i++) {
            fscanf(input, "%d", &p[i]);
        }

        // ��¼��ʼʱ��
        clock_t start = clock();

        // ���㲢������
        matrix_chain_order(p, n, output, time_output);

        // �ͷ��ڴ�
        free(p);
    }

    // �ر��ļ�
    fclose(input);
    fclose(output);
    fclose(time_output);

    return 0;
}

