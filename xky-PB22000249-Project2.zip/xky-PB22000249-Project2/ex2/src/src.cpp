#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <float.h>

// �������ڴ�ӡ e ����
void print_e_table(double **e, int n, FILE *output) {
    fprintf(output, "Table e[i][j] (Expected Cost):\n");
    for (int i = 1; i <= n + 1; i++) {
        for (int j = 1; j <= n; j++) {
            if (j >= i - 1) {
                fprintf(output, "%10.4f ", e[i][j]);
            } else {
                fprintf(output, "          ");
            }
        }
        fprintf(output, "\n");
    }
    fprintf(output, "\n");
}

// �������ڴ�ӡ root ����
void print_root_table(int **root, int n, FILE *output) {
    fprintf(output, "Table root[i][j] (Optimal Root Index):\n");
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (j >= i) {
                fprintf(output, "%7d ", root[i][j]);
            } else {
                fprintf(output, "        ");
            }
        }
        fprintf(output, "\n");
    }
    fprintf(output, "\n");
}

// ������Ŷ���������
void optimal_bst(int n, double *p, double *q, FILE *output, FILE *time_output) {
    double **e = (double **)malloc((n + 2) * sizeof(double *));
    double **w = (double **)malloc((n + 2) * sizeof(double *));
    int **root = (int **)malloc((n + 1) * sizeof(int *));
    for (int i = 0; i <= n + 1; i++) {
        e[i] = (double *)malloc((n + 1) * sizeof(double));
        w[i] = (double *)malloc((n + 1) * sizeof(double));
    }
    for (int i = 0; i <= n; i++) {
        root[i] = (int *)malloc((n + 1) * sizeof(int));
    }

    // ��ʼ�� e �� w �Ļ������
    for (int i = 1; i <= n + 1; i++) {
        e[i][i - 1] = q[i - 1];
        w[i][i - 1] = q[i - 1];
    }

    // ��̬�滮���� e �� root ��
    for (int l = 1; l <= n; l++) {
        for (int i = 1; i <= n - l + 1; i++) {
            int j = i + l - 1;
            e[i][j] = DBL_MAX;
            w[i][j] = w[i][j - 1] + p[j - 1] + q[j];
            for (int r = i; r <= j; r++) {
                double t = e[i][r - 1] + e[r + 1][j] + w[i][j];
                if (t < e[i][j]) {
                    e[i][j] = t;
                    root[i][j] = r;
                }
            }
        }
    }

    // ��� e ���� root �����ļ�
    print_e_table(e, n, output);
    print_root_table(root, n, output);

    // ��¼����ʱ��
    clock_t end = clock();
    double time_taken = ((double)(end)) / CLOCKS_PER_SEC;
    fprintf(time_output, "Time taken for n=%d: %f seconds\n", n, time_taken);

    // �ͷŶ�̬������ڴ�
    for (int i = 0; i <= n + 1; i++) {
        free(e[i]);
        free(w[i]);
    }
    for (int i = 0; i <= n; i++) {
        free(root[i]);
    }
    free(e);
    free(w);
    free(root);
}

int main() {
    // �ļ�·����ȷ��·����ȷ
    FILE *input = fopen("C:\\Users\\StarrySheep1\\Desktop\\xky-PB22000249-Project2\\ex2\\input\\2_2_input.txt", "r");
    FILE *output = fopen("C:\\Users\\StarrySheep1\\Desktop\\xky-PB22000249-Project2\\ex2\\output\\result.txt", "w");
    FILE *time_output = fopen("C:\\Users\\StarrySheep1\\Desktop\\xky-PB22000249-Project2\\ex2\\output\\time.txt", "w");

    if (input == NULL || output == NULL || time_output == NULL) {
        printf("Error opening files.\n");
        return 1;
    }

    int n;
    while (fscanf(input, "%d", &n) == 1) {  // ѭ����ȡÿ�����ݼ�
        double *p = (double *)malloc(n * sizeof(double));
        double *q = (double *)malloc((n + 1) * sizeof(double));

        // ��ȡ p �� q ����
        for (int i = 0; i < n; i++) {
            fscanf(input, "%lf", &p[i]);
        }
        for (int i = 0; i <= n; i++) {
            fscanf(input, "%lf", &q[i]);
        }

        // ��¼��ʼʱ��
        clock_t start = clock();

        // ���㲢������
        optimal_bst(n, p, q, output, time_output);

        // �ͷ��ڴ�
        free(p);
        free(q);
    }

    // �ر��ļ�
    fclose(input);
    fclose(output);
    fclose(time_output);

    return 0;
}

