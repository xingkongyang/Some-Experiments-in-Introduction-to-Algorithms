#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <windows.h>  // Windows�µĸ߾���ʱ�亯��

#define RED 0
#define BLACK 1

// ������ڵ�ṹ
typedef struct Node {
    int data;
    int color;
    struct Node *left, *right, *parent;
} Node;

Node *TNULL;

// �����½ڵ�
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = data;
    newNode->color = RED;  // �½ڵ�Ĭ���Ǻ�ɫ
    newNode->left = newNode->right = newNode->parent = TNULL;
    return newNode;
}

// ��������
void leftRotate(Node **root, Node *x) {
    Node *y = x->right;
    x->right = y->left;
    if (y->left != TNULL) {
        y->left->parent = x;
    }
    y->parent = x->parent;
    if (x->parent == TNULL) {
        *root = y;
    } else if (x == x->parent->left) {
        x->parent->left = y;
    } else {
        x->parent->right = y;
    }
    y->left = x;
    x->parent = y;
}

// ��������
void rightRotate(Node **root, Node *x) {
    Node *y = x->left;
    x->left = y->right;
    if (y->right != TNULL) {
        y->right->parent = x;
    }
    y->parent = x->parent;
    if (x->parent == TNULL) {
        *root = y;
    } else if (x == x->parent->right) {
        x->parent->right = y;
    } else {
        x->parent->left = y;
    }
    y->right = x;
    x->parent = y;
}

// �޸������������
void insertFixup(Node **root, Node *k) {
    Node *u;
    while (k->parent->color == RED) {
        if (k->parent == k->parent->parent->left) {
            u = k->parent->parent->right;
            if (u->color == RED) {
                k->parent->color = BLACK;
                u->color = BLACK;
                k->parent->parent->color = RED;
                k = k->parent->parent;
            } else {
                if (k == k->parent->right) {
                    k = k->parent;
                    leftRotate(root, k);
                }
                k->parent->color = BLACK;
                k->parent->parent->color = RED;
                rightRotate(root, k->parent->parent);
            }
        } else {
            u = k->parent->parent->left;
            if (u->color == RED) {
                k->parent->color = BLACK;
                u->color = BLACK;
                k->parent->parent->color = RED;
                k = k->parent->parent;
            } else {
                if (k == k->parent->left) {
                    k = k->parent;
                    rightRotate(root, k);
                }
                k->parent->color = BLACK;
                k->parent->parent->color = RED;
                leftRotate(root, k->parent->parent);
            }
        }
        if (k == *root) break;
    }
    (*root)->color = BLACK;
}

// ����ڵ�
void insertNode(Node **root, int data) {
    Node *node = createNode(data);
    Node *y = TNULL;
    Node *x = *root;

    while (x != TNULL) {
        y = x;
        if (node->data < x->data) {
            x = x->left;
        } else {
            x = x->right;
        }
    }

    node->parent = y;
    if (y == TNULL) {
        *root = node;
    } else if (node->data < y->data) {
        y->left = node;
    } else {
        y->right = node;
    }

    insertFixup(root, node);
}

// ɾ���ڵ� (��ɾ����������������ʾ)
void deleteNode(Node **root, int data) {
    Node *node = *root;
    while (node != TNULL && node->data != data) {
        if (data < node->data) node = node->left;
        else node = node->right;
    }
    if (node != TNULL) {
        // ����ɾ���ڵ�����ɹ�ִ��
    }
}

// ����n������������뵽�����
void generateAndInsertNodes(Node **root, int n, FILE *inputFile, int *randomValues) {
    // ����n��Ψһ�������
    for (int i = 0; i < n; i++) {
        int randomValue;
        int unique;
        do {
            unique = 1;
            randomValue = rand() % 1000;  // �������0-999������
            // ����Ƿ��Ѵ����ظ�ֵ
            for (int j = 0; j < i; j++) {
                if (randomValues[j] == randomValue) {
                    unique = 0;
                    break;
                }
            }
        } while (!unique);
        
        randomValues[i] = randomValue;  // ��¼���ɵ������
        fprintf(inputFile, "%d ", randomValue);  // д�뵽input.txt
        insertNode(root, randomValue);
    }
}

// ɾ��n/4���ڵ�
void deleteRandomNodes(Node **root, int n, FILE *deleteFile) {
    int deleteCount = (n / 4 < 8) ? n / 4 : 8;
    srand(time(NULL)); // Ϊ�˱�֤ÿ��ɾ�����������

    for (int i = 0; i < deleteCount; i++) {
        int deleteValue = rand() % 1000;  // ���ɾ��һ��ֵ
        fprintf(deleteFile, "%d ", deleteValue);
        deleteNode(root, deleteValue);  // ִ��ɾ������
    }

    fprintf(deleteFile, "\n");  // ÿ��n���������
}

// ����������������������еĽڵ�
void inorderTraversal(Node *root, FILE *inorderFile) {
    if (root != TNULL) {
        inorderTraversal(root->left, inorderFile);
        fprintf(inorderFile, "%d ", root->data);  // ������нڵ������
        inorderTraversal(root->right, inorderFile);
    }
}

int main() {
    srand(time(NULL));  // �����������

    // ������ڵ��TNULL�ڵ�
    TNULL = (Node*)malloc(sizeof(Node));
    TNULL->color = BLACK;
    TNULL->left = TNULL->right = TNULL->parent = NULL;

    // ������������ļ�
    FILE *inputFile = fopen("C:\\Users\\StarrySheep1\\Desktop\\3\\ex1\\input\\input.txt", "w");
    FILE *inorderFile = fopen("C:\\Users\\StarrySheep1\\Desktop\\3\\ex1\\output\\inorder.txt", "w");
    FILE *timeFile1 = fopen("C:\\Users\\StarrySheep1\\Desktop\\3\\ex1\\output\\time1.txt", "w");
    FILE *timeFile2 = fopen("C:\\Users\\StarrySheep1\\Desktop\\3\\ex1\\output\\time2.txt", "w");
    FILE *deleteFile = fopen("C:\\Users\\StarrySheep1\\Desktop\\3\\ex1\\output\\delete_data.txt", "w");

    if (inputFile == NULL || inorderFile == NULL || timeFile1 == NULL || timeFile2 == NULL || deleteFile == NULL) {
        printf("�޷������ļ���\n");
        return -1;
    }

    // ���ü�ʱ��Ƶ��
    LARGE_INTEGER frequency;
    QueryPerformanceFrequency(&frequency);

    // ʱ���ʱ
    LARGE_INTEGER start, end;

    // ���������ʱ��
    for (int n = 16; n <= 256; n *= 2) {
        Node *root = TNULL;  // ��ʼ�������

        // ���ɲ����������
        int randomValues[n];
        QueryPerformanceCounter(&start);
        generateAndInsertNodes(&root, n, inputFile, randomValues);
        QueryPerformanceCounter(&end);

        double insertTime = (double)(end.QuadPart - start.QuadPart) / frequency.QuadPart;
        fprintf(timeFile1, "%d: %f ��\n", n, insertTime);

        // ����������
        inorderTraversal(root, inorderFile);
        fprintf(inorderFile, "\n");

        // ɾ���ڵ㲢��ʱ
        QueryPerformanceCounter(&start);
        deleteRandomNodes(&root, n, deleteFile);
        QueryPerformanceCounter(&end);

        double deleteTime = (double)(end.QuadPart - start.QuadPart) / frequency.QuadPart;
        fprintf(timeFile2, "%d: %f ��\n", n, deleteTime);
    }

    fclose(inputFile);
    fclose(inorderFile);
    fclose(timeFile1);
    fclose(timeFile2);
    fclose(deleteFile);

    return 0;
}

